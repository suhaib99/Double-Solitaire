package main;

import javafx.animation.AnimationTimer;

public class Handler extends AnimationTimer {

    @Override
    public void handle(long now) {

    }
}
