package main;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javax.swing.*;
import java.io.FileInputStream;

/**
 * Class containing Suit and Value of a playing card
 */
public class Card{

    private static final String[] NAMES = {"Ace", "2","3","4","5","6","7","8","9","10","Jack","Queen","King"};
    private static final String[] SUITS = {"spade", "club", "heart", "diamond"};
    // 1: Spade, 2: Club, 3: Hearts, 4: Diamond
    private int suit;

    // Ace: 1, Jack: 11, Queen: 12, King: 13
    private int rank;

    public static final int WIDTH = 75;
    public static final int HEIGHT = 113;

    private boolean faceUp;

    private boolean isHeld = false;

    // 0: Red, 1: Black
    private int color;

    private double x;
    private double y
	
	/**	
	*Sets colour for cards according to their suits.
	*@param : suit , rank.
	*@return : -
	*/

    Card(int suit, int rank){
        this.suit = suit;
        this.rank = rank;
        this.faceUp = false;

        if (this.suit == 1 || this.suit == 2){
            this.color = 1;

        } else if (this.suit == 3 || this.suit == 4){
            this.color = 0;
        }
    }
	
	/**	
	*Checks if the card is face up or flipped down.
	*@param : -
	*@return : returns true if face up.
	*/
	boolean getFaceUp(){
        return this.faceUp;
    }
	
	/**	
	*Gets the number of the card from which rank is determined. (Ace: 1, Jack: 11, Queen: 12, King: 13)
	*@param : -
	*@return : returns the rank of the card. Ace: 1, Jack: 11, Queen: 12, King: 13
	*/
    int getNumber() {
        return this.rank;
    }
	
	/**	
	*Gets the suit of the card.
	*@param : -
	*@return : Returns the suit of the card.  1: Spade, 2: Club, 3: Hearts, 4: Diamond
	*/
    int getSuit() {
        return suit;
    }

	/**	
	* Gets the colour of the card, red or black.
	*@param : -
	*@return : Color of the card. 0: Red, 1: Black.
	*/
    int getColor(){
        return color;
    }

    public boolean getHeld(){
        return isHeld;
    }
/**	
	*If a card is facing up it flips it so it is not.
	*@param : -
	*@return : -
	*/
    void flip(){
        this.faceUp = !this.faceUp;
    }
	
	
    boolean isKing(){
        return (getNumber() == 13);
    }
    boolean isQueen(){
        return (getNumber() == 12);
    }
    boolean isJack(){
        return (getNumber() == 11);
    }

    boolean isAce(){
        return (getNumber() == 1);
    }
    /**	
	*gets the name of the card
	*@param : -
	*@return : name of the card
	*/
    String getName(){
        return NAMES[this.getNumber() - 1];
    }

	/**	
	*gets the name of the suit of the card.
	*@param : -
	*@return : name of the suit.
	*/
    String getSuitName(){
        return SUITS[this.getSuit() - 1];
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setHeld(boolean held) {
        isHeld = held;
    }

    // team 1: blue, team 2: red
	
	/**	
	*Displays cards for each player while alternating between players.
	*@param : team. 1 for blue, 2 for red.
	*@return : Images of cards.
	*/
    public Image displayCard(int team){
        Image cardImage;

        try {
            if (this.faceUp) {
                cardImage = new Image(new FileInputStream(String.format("Double-Solitaire/src/res/Decks/pngs/%s",
                        this.getSuitName() + this.getName() + ".png")));
                return cardImage;
            } else if (team == 1){
                cardImage = new Image(new FileInputStream("Double-Solitaire/src/res/Decks/pngs/blueBack.png"));
                return cardImage;
            } else if (team == 2){
                cardImage = new Image(new FileInputStream("Double-Solitaire/src/res/Decks/pngs/redBack.png"));
                return cardImage;
            }

        }
        catch(java.io.FileNotFoundException e) {
            System.out.println("FileNotFound");
        }
        return null;
    }

    public static void main(String[] args){


    }
}
