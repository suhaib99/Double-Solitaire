package main;

import javafx.scene.image.Image;
import java.util.ArrayList;

public class CardPile {
    private ArrayList<Card> cardList = new ArrayList<>();

    ArrayList<Card> getCardList(){
        return new ArrayList<>(cardList);
    }

    boolean empty(){
        return cardList.isEmpty();
    }

    private int x;
    private int y;
    
	/**	
	*Gets the size of the card list.
	*@param : -
	*@return : Size of the list of cards. Returns null if cardlist is empty.
	*/
    Card top(){
        if (!empty())
            return cardList.get(cardList.size() - 1);

        else
            return null;
    }


	/**	
	*allows user to flip through the Card pile.
	*@param : -
	*@return : Returns the new card when flipped through the top card.
	*/
    Card pop() {
        if (!empty()) {
            Card return_val = this.top();
            cardList.remove(cardList.size() - 1);
            return return_val;
        }
        else
            return null;

    }

	/**	
	*Gets the index of card.
	*@param : Card
	*@return : index of card.
	*/
    int getIndex(Card card){
        return this.cardList.indexOf(card);
    }

	
	
    ArrayList<Card> select(int end){
        //do nothing to be overridden
        return null;
    }

    ArrayList<Card> select(){
        //do nothing to be overriden in TablePile
        return null;
    }

	/**	
	*Moves the card to the top
	*@param : Card.
	*@return : -
	*/
    void addToFront(Card aCard){
        cardList.add(0, aCard);
    }

	/**	
	*Gets x and y value of the card
	*@param : ArrayList<Card> card
	*@return : -
	*/
    void addCard(ArrayList<Card> card){
        cardList.addAll(card);
        for (Card card1: card) {
            card1.setX(this.getX());
            card1.setY(this.getY());
        }
    }

	/**	
	*
	*@param : -
	*@return : -
	*/
    void addCard(Card card){
        cardList.add(card);
        card.setY(this.getX());
        card.setX(this.getY());
        card.setHeld(false);
    }

    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    boolean contains(double mouseX, double mouseY){
        return (mouseX > this.x && mouseX < this.x + Card.WIDTH && mouseY > this.y && mouseY < this.y + Card.HEIGHT);
    }

    int getNoCards(){
        return cardList.size();
    }

    boolean canAccept(ArrayList<Card> aCard){
        // Overridden
        return false;
    }

    // team number is passed as argument
    ArrayList<Image> display(int team){
        ArrayList<Image> images = new ArrayList<>();
        for (Card card: this.getCardList()){
            images.add(card.displayCard(team));
        }
        return images;
    }

    public static void main(String[] args){
        CardPile testpile = new CardPile();

        System.out.println(testpile.getCardList().toString());
        System.out.println(testpile.getCardList().get(0).getNumber());
        System.out.println(testpile.getCardList().get(1).getNumber());
        System.out.println(testpile.pop());
        System.out.println(testpile.getCardList().toString());


    }

}
