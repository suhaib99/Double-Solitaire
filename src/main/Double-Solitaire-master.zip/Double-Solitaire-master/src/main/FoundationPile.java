package main;

import java.util.ArrayList;

public class FoundationPile extends CardPile {

	/**	
	*Determines which card can be added to the foundation pile. Ace has to be the first card on the foundation pile.
	*@param : Arraylist<Card> aCard
	*@return : Returns true if the card is an Ace.
	*/
    @Override
    boolean canAccept(ArrayList<Card> aCard){
        if (this.empty() && aCard.get(0).isAce()){
            return true;
        } else
        return (aCard.get(0).getSuit() == this.top().getSuit()) && (aCard.get(0).getNumber() == this.top().getNumber() - 1);
    }


}
