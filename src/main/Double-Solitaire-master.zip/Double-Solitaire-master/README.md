# Double-Solitaire

## To start the game simply run the MainVisual.main 

### Commands for movement follow the form:

To shuffle through the discard pile:
Simply click on it.

####To move a card from one pile to another :
(The same steps apply to move a card from discard pile to table pile, table pile to foundation pile and from one table pile to another table pile) 
1. Click on the card you want to move, 
2. Drag and Drop it to the destination pile
